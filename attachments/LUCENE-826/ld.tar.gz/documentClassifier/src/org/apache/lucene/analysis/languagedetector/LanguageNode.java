package org.apache.lucene.analysis.languagedetector;

import java.io.File;
import java.util.HashSet;
import java.util.Set;

/**
 * User: kalle
 * Date: 2007-mar-05
 * Time: 17:05:03
 */
public abstract class LanguageNode {

  // private static Log log = LogFactory.getLog(Language.class);
  // private static long serialVersionUID = 1l;

  private LanguageBranch parent;

  public LanguageNode(LanguageBranch parent) {
    this.parent = parent;
    if (parent != null) {
      parent.getChildren().add(this);
    }
  }

  public LanguageBranch getParent() {
    return parent;
  }

  /**
   * todo refactor, move to classifier
   */
  public File getDataPath() {
    return new File(getParent().getDataPath(), toString());
  }

  /**
   * todo refactor, move to classifier
   */
  public File getTestDataPath() {
    return new File(getDataPath(), "test data");
  }

  /**
   * todo refactor, move to classifier
   */
  public File getTrainingDataPath() {
    return new File(getDataPath(), "training data");
  }

  public LanguageRoot getRoot() {
    return getParent().getRoot();
  }

  public double distanceToParent = 0d;


  public double getDistanceToParent() {
    return distanceToParent;
  }

  public void setDistanceToParent(double distanceToParent) {
    this.distanceToParent = distanceToParent;
  }

  public double distanceTo(LanguageNode target) {
    Set<LanguageNode> visitedNodes = new HashSet<LanguageNode>();
    visitedNodes.add(this);
    return distanceTo(target, visitedNodes, 0d);
  }

  protected abstract Double distanceTo(LanguageNode target, Set<LanguageNode> visitedNodes, double currentDistance);

}

package org.apache.lucene.analysis.languagedetector;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * User: kalle
 * Date: 2007-mar-05
 * Time: 17:17:31
 */
public class LanguageBranch extends LanguageNode {

  // private static Log log = LogFactory.getLog(LanguageBranch.class);
  // private static long serialVersionUID = 1l;

  private String name;

  private List<LanguageNode> children = new ArrayList<LanguageNode>();

  public LanguageBranch(LanguageBranch parent, String name) {
    super(parent);
    this.name = name;
  }

  public String getName() {
    return name;
  }

  public String toString() {
    return getName();
  }

  public List<LanguageNode> getChildren() {
    return children;
  }


  protected Double distanceTo(LanguageNode target, Set<LanguageNode> visitedNodes, double currentDistance) {
    visitedNodes.add(this);
    if (!visitedNodes.contains(getParent())) {
      Double ret = getParent().distanceTo(target, visitedNodes, currentDistance + getDistanceToParent());
      if (ret != null) {
        return ret+distanceToParent;
      }
    }
    for (LanguageNode child : getChildren()) {
      if (!visitedNodes.contains(child)) {
        Double ret = child.distanceTo(target, visitedNodes, currentDistance + child.getDistanceToParent());
        if (ret != null) {
          return ret;
        }
      }
    }
    return null;
  }
}

package org.apache.lucene.analysis.languagedetector;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.TokenStream;

import java.io.Reader;
import java.util.Collections;

/**
 * User: kalle
 * Date: 2007-mar-04
 * Time: 23:05:30
 */
public class LanguageClassifierAnalyzer extends StandardAnalyzer {

  // private static Log log = LogFactory.getLog(LangugageDetectorAnalyzer.class);
  // private static long serialVersionUID = 1l;


  public LanguageClassifierAnalyzer() {
    super(Collections.emptySet());
  }

  public TokenStream tokenStream(String fieldName, Reader reader) {
    //return super.tokenStream(fieldName,  reader);
    return new LanguageClassifierTokenFilter(super.tokenStream(fieldName, reader));
  }
}

package org.apache.lucene.analysis.languagedetector;


import junit.framework.TestCase;
import org.cyberneko.html.parsers.DOMParser;
import org.xml.sax.InputSource;

import java.io.File;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.net.URL;

/**
 * User: kalle
 * Date: 2007-mar-05
 * Time: 02:52:15
 */
public class TestLanguageDetector extends TestCase {

  // private static Log log = LogFactory.getLog(TestLanguageDetector.class);
  // private static long serialVersionUID = 1l;

  public static void testEquals(Object string, Object string2) {
    try {
      assertEquals(string, string2);
    } catch (Throwable e) {
      //System.err.println(e.getMessage());
      System.out.println("This exception is just a warning: " + e.getMessage());
      System.out.println(e.getStackTrace()[3].toString());
    }
  }


  public void test() throws Exception {
    LanguageRoot root = new LanguageRoot(new File("documentClassifier/language root"));

    root.addBranch("uralic");
    root.addBranch("fino-ugric", "uralic");

    root.addBranch("ugric", "uralic");
    root.addLanguage("ugric", "hun", "hungarian", "hu", "Magyarorsz%C3%A1g");

    root.addLanguage("fino-ugric", "fin", "finnish", "fi", "Suomi");
    //root.addLanguage("fino-ugric", "sme", "sami", "se", "S%C3%A1pmi"); todo select some page. lapland?
    root.addLanguage("fino-ugric", "est", "estonian", "et", "Eesti");

    root.addBranch("proto-indo european");

    root.addBranch("italic", "proto-indo european");
    root.addBranch("latino-faliscan", "italic");
    root.addBranch("latin", "latino-faliscan");
    root.addLanguage("latin", "ita", "italian", "it", "Italia");
    root.addLanguage("latin", "fre", "french", "fr", "France");
    root.addLanguage("latin", "pot", "portugese", "pt", "Portugal");
    root.addLanguage("latin", "spa", "spanish", "es", "Espa%C3%B1a");

    root.addBranch("balto-slavic", "proto-indo european");
    root.addBranch("baltic", "balto-slavic");
    root.addLanguage("baltic", "lit", "lithuanian", "lt", "Lietuva");
    root.addLanguage("baltic", "lav", "latvian", "lv", "Latvija");

    root.addBranch("slavic", "balto-slavic");
    root.addBranch("east slavic", "slavic");
    root.addLanguage("east slavic", "ukr", "ukranian", "uk", "%D0%A3%D0%BA%D1%80%D0%B0%D1%97%D0%BD%D0%B0");
    root.addLanguage("east slavic", "bel", "belarussian", "be", "%D0%91%D0%B5%D0%BB%D0%B0%D1%80%D1%83%D1%81%D1%8C");
    root.addLanguage("east slavic", "rus", "russian", "ru", "%D0%A0%D0%BE%D1%81%D1%81%D0%B8%D1%8F");

    root.addBranch("south slavic", "slavic");
    root.addLanguage("south slavic", "slv", "slovenian", "sl", "Slovenija");
    root.addLanguage("south slavic", "hr", "croatian", "hr", "Hrvatska");
    root.addLanguage("south slavic", "scc", "serbian", "sr", "%D0%A1%D1%80%D0%B1%D0%B8%D1%98%D0%B0");
    root.addLanguage("south slavic", "bos", "bosnian", "bs", "Bosna_i_Hercegovina");
    root.addLanguage("south slavic", "mkd", "macedonian", "mk", "%D0%A0%D0%B5%D0%BF%D1%83%D0%B1%D0%BB%D0%B8%D0%BA%D0%B0_%D0%9C%D0%B0%D0%BA%D0%B5%D0%B4%D0%BE%D0%BD%D0%B8%D1%98%D0%B0");
    root.addLanguage("south slavic", "bul", "bulgarian", "bg", "%D0%91%D1%8A%D0%BB%D0%B3%D0%B0%D1%80%D0%B8%D1%8F");

    root.addBranch("west slavic", "slavic");
    root.addLanguage("west slavic", "pol", "polish", "pl", "Polska");
    root.addLanguage("west slavic", "cze", "czech", "cs", "%C4%8Cesko");
    root.addLanguage("west slavic", "slo", "slovak", "sk", "Slovensko");

    root.addBranch("indo-iranian", "proto-indo european");
    root.addBranch("indic", "indo-iranian");
    root.addBranch("vedic sanskrit", "indic");
    root.addBranch("middle indic", "vedic sanskrit");
//    root.addLanguage("middle indic", "", "romany", "", "");
//    root.addLanguage("middle indic", "", "urdu", "", "");
//    root.addLanguage("middle indic", "", "punjabi", "", "");
//    root.addLanguage("middle indic", "", "sindhi", "", "");
//    root.addLanguage("middle indic", "", "hindi", "", "");
//    root.addLanguage("middle indic", "", "guajarati", "", "");
//    root.addLanguage("middle indic", "", "marathi", "", "");
//    root.addLanguage("middle indic", "", "sinhalese", "", "");
//    root.addLanguage("middle indic", "", "bihari", "", "");
//
    root.addBranch("classic sanskrit", "vedic sanskrit");
//    root.addLanguage("classic sanskrit", "", "bengali", "", "");
//    root.addLanguage("classic sanskrit", "", "assamese", "", "");
//
//
    root.addBranch("iranian", "indo-iranian");
    root.addBranch("northeast iranian", "iranian");
//    root.addLanguage("northeast iranian", "", "khotanese", "", "");
//
    root.addBranch("central iranian", "iranian");
//    root.addLanguage("central iranian", "", "sogdian", "", "");
//    root.addLanguage("central iranian", "", "bactrian", "", "");
//    root.addLanguage("central iranian", "", "parthian", "", "");
//    root.addLanguage("central iranian", "", "avestan", "", "");
//    root.addLanguage("central iranian", "", "ossetic", "", "");
//    root.addLanguage("central iranian", "", "pashto", "", "");
//    root.addLanguage("central iranian", "", "baluchi", "", "");
//    root.addLanguage("central iranian", "", "kurdish", "", "");

    root.addBranch("southwest iranian", "iranian");
    root.addBranch("old persian", "southwest iranian");
    root.addBranch("middle persian", "old persian");
    root.addLanguage("middle persian", "per", "modern persian (farsi)", "fa", "%D8%A7%DB%8C%D8%B1%D8%A7%D9%86");
    //root.addLanguage("middle persian", "tgk", "tajik", "??", "??");


    root.addBranch("armenian", "proto-indo european");
    root.addLanguage("armenian", "arm", "armenian", "hy", "%D5%80%D5%A1%D5%B5%D5%A1%D5%BD%D5%BF%D5%A1%D5%B6");

    root.addBranch("hellenic", "proto-indo european");
    root.addLanguage("hellenic", "gre", "greek", "el", "%CE%95%CE%BB%CE%BB%CE%AC%CE%B4%CE%B1");

    root.addBranch("germanic", "proto-indo european");
    root.addBranch("northern germanic", "germanic");

    // norse
    root.addBranch("old norse", "northern germanic");
    root.addBranch("old icelandic", "old norse");
    root.addLanguage("old icelandic", "isl", "islandic", "is", "%C3%8Dsland");
    root.addLanguage("old icelandic", "fao", "faroese", "fo", "F%C3%B8royar");

    root.addBranch("old norwegian", "old norse");
    root.addBranch("middle norwegian", "old norwegian");
    root.addLanguage("middle norwegian", "nor", "norwegian", "no", "Norge");

    // danish
    root.addBranch("old danish", "northern germanic");
    root.addBranch("middle danish", "old danish");
    root.addLanguage("middle danish", "dan", "danish", "da", "Danmark");

    // swedish
    root.addBranch("old swedish", "northern germanic");
    root.addBranch("middle swedish", "old swedish");
    root.addLanguage("middle swedish", "swe", "swedish", "sv", "Sverige");

    /// west germanic    
    root.addBranch("west germanic", "germanic");

    // english
    root.addBranch("old english", "west germanic");
    root.addBranch("middle english", "old english");
    root.addLanguage("middle english", "eng", "english", "en", "UK");

    // german
    root.addBranch("old high german", "west germanic");
    root.addBranch("middle high german", "old high german");
    root.addLanguage("old high german", "ger", "german", "de", "Deutschland");
    //root.addLanguage("old high german", "yid", "yiddish", "yi", "");

    root.addBranch("old saxon", "west germanic");
    root.addBranch("middle low german", "old saxon");
    root.addLanguage("middle low german", "nds", "low german", "nds", "Deutschland");

    // frisian
    root.addBranch("old frisian", "west germanic");
    root.addLanguage("old frisian", "fry", "frisian", "fy", "Nederl%C3%A2n");

    // franconian
    root.addBranch("old frisian", "west germanic");
    root.addBranch("middle dutch", "west germanic");
    root.addLanguage("middle dutch", "nld", "dutch", "nl", "Nederland");
    root.addLanguage("middle dutch", "afr", "afrikaans", "af", "Nederland");

    System.out.println("Supported languages("+root.getLanguagesByISO().size()+"):");
    for (Language language : root.getLanguagesByISO().values()) {
      System.out.println(language.getEnglishName());
    }
    System.out.println();

    root.mkdirs();

    LanguageClassifier classifier = new LanguageClassifier(root);

    if (!new File(root.getDataPath(), "trainingData.arff").exists()) {
      long ms = System.currentTimeMillis();
      classifier.compileTrainingData();
      System.out.println("Time to compile training data: " + (System.currentTimeMillis() - ms) / 1000 + " seconds");
    }

    long ms = System.currentTimeMillis();
    classifier.buildClassifier();
    System.out.println("Time to build classifier: " + (System.currentTimeMillis() - ms) / 1000 + " seconds");

    for (Language language : root.getLanguagesByISO().values()) {
      System.out.println("Testing " + language);
      int truePositives = 0;
      int falsePositives = 0;
      long classificationTime = 0;
      while (truePositives <= 20) {
        DOMParser parser = new DOMParser();
        parser.parse(new InputSource(new InputStreamReader(new URL("http://" + language.getWikipediaDomainPrefix() + ".wikipedia.org/wiki/Special:Random").openStream())));
        StringWriter sw = new StringWriter(2000);
        LanguageClassifier.write(LanguageClassifier.getNode(parser.getDocument(), new int[]{1, 3, 1, 1, 1}), "", "0", sw);
        String content = sw.toString().replaceAll("\\s+", " ");
        if (content.length() > 160) {
          ms = System.currentTimeMillis();
          Language _class = classifier.classify(content);
          classificationTime += System.currentTimeMillis() - ms;
          if (language.equals(_class)) {
            truePositives++;
            System.out.print(".");
          } else {
            System.out.print("\n");
            String title = LanguageClassifier.getNode(parser.getDocument(), new int[]{1, 1, 11, 0}).getTextContent();
            System.out.println("False positive: " + title);
            System.out.println("Was " + _class + ", expected " + language);
            falsePositives++;
          }
        }
      }
      System.out.println();
      System.out.println("=== Summary for " + language + "===");
      System.out.println("True positives:\t" + truePositives);
      System.out.println("False positives:\t" + falsePositives);
      System.out.println("ms/classification:\t" + (int) ((double) classificationTime / (double) (truePositives + falsePositives)));
      System.out.println("");
    }

  }
}

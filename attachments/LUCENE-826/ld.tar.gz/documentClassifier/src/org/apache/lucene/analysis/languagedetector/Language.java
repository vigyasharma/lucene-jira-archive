package org.apache.lucene.analysis.languagedetector;

import java.util.Set;

/**
 * User: kalle
 * Date: 2007-mar-05
 * Time: 17:18:02
 */
public class Language extends LanguageNode {

  // private static Log log = LogFactory.getLog(Language.class);
  // private static long serialVersionUID = 1l;

  private String ISO;
  private String englishName;
  private String homeCountryNative;

  private String wikipediaDomainPrefix;


  public Language(LanguageBranch parent, String ISO, String englishName, String wikipediaDomainPrefix, String homeCountryNative) {
    super(parent);
    this.ISO = ISO;
    this.englishName = englishName;
    this.homeCountryNative = homeCountryNative;
    this.wikipediaDomainPrefix = wikipediaDomainPrefix;
  }

  public String getISO() {
    return ISO;
  }

  public String toString() {
    return getEnglishName();
  }

  public String getEnglishName() {
    return englishName;
  }

  public String getHomeCountryNative() {
    return homeCountryNative;
  }

  public String getWikipediaDomainPrefix() {
    return wikipediaDomainPrefix;
  }

  protected Double distanceTo(LanguageNode target, Set<LanguageNode> visitedNodes, double currentDistance) {
    if (target.equals(this)) {
      return currentDistance;
    }
    visitedNodes.add(this);
    if (!visitedNodes.contains(getParent())) {
      Double ret = getParent().distanceTo(target, visitedNodes, getDistanceToParent());
      if (ret != null) {
        return ret + distanceToParent;
      }
    }
    return null;
  }
  
}

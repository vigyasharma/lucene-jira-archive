package org.apache.lucene.analysis.languagedetector;

import org.apache.lucene.analysis.Token;
import org.apache.lucene.analysis.TokenStream;
import org.apache.xerces.dom.AttrNSImpl;
import org.apache.xerces.dom.TextImpl;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
import org.cyberneko.html.parsers.DOMParser;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import weka.attributeSelection.InfoGainAttributeEval;
import weka.attributeSelection.Ranker;
import weka.classifiers.Classifier;
import weka.classifiers.functions.SMO;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.SelectedTag;
import weka.filters.Filter;
import weka.filters.supervised.attribute.AttributeSelection;
import weka.filters.unsupervised.attribute.Copy;
import weka.filters.unsupervised.attribute.Remove;
import weka.filters.unsupervised.attribute.StringToWordVector;

import java.io.*;
import java.net.URL;
import java.net.URLDecoder;
import java.util.*;
import java.util.regex.Pattern;

/**
 * User: kalle
 * Date: 2007-mar-04
 * Time: 02:54:56
 */
public class LanguageClassifier {

  private static Log log = LogFactory.getLog(LanguageClassifier.class);
  // private static long serialVersionUID = 1l;

  private LanguageRoot root;

  private LanguageClassifierAnalyzer analyzer = new LanguageClassifierAnalyzer();

  private Classifier classifier;

  private int trainingInstancesPerLanguage = 1000;
  private int extractedNGramsPerLanguage = 1000;
  private int featuredNGramsPerLanguage = 200;

  private Set<String> grams;
  private Instances instances;

  public LanguageClassifier(LanguageRoot root) {
    this.root = root;
    classifier = new SMO();
    //classifier.setKernel(new NormalizedPolyKernel());
  }

  public Classifier getClassifier() {
    return classifier;
  }

  public Instances getInstances() {
    return instances;
  }

  private Instances applyFilter(Instances data, Filter filter) throws Exception {
    for (int i = 0; i < data.numInstances(); i++) {
      filter.input(data.instance(i));
    }
    filter.batchFinished();
    Instances newData = filter.getOutputFormat();
    Instance processed;
    while ((processed = filter.output()) != null) {
      newData.add(processed);
    }
    return newData;
  }

  public Language classify(String text) throws Exception {

    StringBuilder sb = new StringBuilder(5000);
    sb.append("@RELATION langdetect\n@ATTRIBUTE csv_ngrams STRING\n@DATA\n\"");
    TokenStream ts = analyzer.tokenStream(null, new StringReader(text));
    Token token = ts.next();
    while (token != null) {
      sb.append(token.termText());
      token = ts.next();
      if (token != null) {
        sb.append(';');
      }
    }
    sb.append("\"");

    Instances factoryInstances = new Instances(new StringReader(sb.toString()));

    StringToWordVector stringToWordVector = new StringToWordVector(extractedNGramsPerLanguage * root.getLanguagesByISO().size());
    stringToWordVector.setInputFormat(factoryInstances);
    stringToWordVector.setDelimiters(";");
    stringToWordVector.setNormalizeDocLength(new SelectedTag(StringToWordVector.FILTER_NORMALIZE_ALL, StringToWordVector.TAGS_FILTER));
    stringToWordVector.setOutputWordCounts(true);

    factoryInstances = applyFilter(factoryInstances, stringToWordVector);
    Instance factoryInstance = factoryInstances.instance(0);

    Instance instance = new Instance(instances.numAttributes());
    instance.setDataset(instances);
    for (int i = 0; i < factoryInstances.numAttributes() - 1; i++) {
      String tokenName = factoryInstances.attribute(i).name();
      if (grams.contains(tokenName)) {
        instance.setValue(instances.attribute(tokenName), factoryInstance.value(i));
      }
    }

    for (int i = 0; i < instance.numAttributes() - 1; i++) {
      if (instance.isMissing(i)) {
        instance.setValue(i, 0d);
      }
    }

    String _class = this.instances.classAttribute().value((int) classifier.classifyInstance(instance));
    return root.getLanguagesByISO().get(_class);
  }

  public void buildClassifier() throws Exception {
    System.out.println("loading training data");
    Reader r = new InputStreamReader(new FileInputStream(new File(root.getDataPath(), "trainingData.arff")), "UTF8");
    Instances instances = new Instances(r);
    r.close();
    instances.setClass(instances.attribute("Copy of class"));

    grams = new HashSet<String>(instances.numAttributes());
    for (int i = 0; i < instances.numAttributes() - 1; i++) {
      grams.add(instances.attribute(i).name());
    }

    System.out.println("building classifier");
    classifier.buildClassifier(instances);
    this.instances = instances;
  }

  public void compileTrainingData() throws Exception {
    for (Language countryLanguage : root.getLanguagesByISO().values()) {

      //System.out.println(countryLanguage.getEnglishName());

      StringBuilder sb = new StringBuilder(100);
      sb.append("http://");
      sb.append(countryLanguage.getWikipediaDomainPrefix());
      sb.append(".wikipedia.org/wiki/");
      sb.append(countryLanguage.getHomeCountryNative());
      System.out.println(sb.toString());
      DOMParser nativeCountryParser = new DOMParser();

      nativeCountryParser.parse(new InputSource(new InputStreamReader(new URL(sb.toString()).openStream())));


      for (Language language : root.getLanguagesByISO().values()) {

        //System.out.println(language.getEnglishName());

        // find the article about this country in the training language
        // by accessing the link to the language in the native country page.

        String countryName = null;
        DOMParser parser = null;

        if (countryLanguage.equals(language)) {

          // ok, this is the home country of the language,
          // so we just import the content of this
          countryName = countryLanguage.getHomeCountryNative();
          parser = nativeCountryParser;

        } else {
          for (Node node : searchRecursive(getNode(nativeCountryParser.getDocument(), new int[]{1, 3, 1, 3}), ".*", TextImpl.class)) {
            AttrNSImpl href = (AttrNSImpl) node.getParentNode().getAttributes().getNamedItem("href");
            if (href != null) {
              if (href.getValue().startsWith("http://" + language.getWikipediaDomainPrefix() + ".wikipedia.org/wiki/")) {
                System.out.println(href.getValue());
                parser = new DOMParser();
                parser.parse(new InputSource(new InputStreamReader(new URL(href.getValue()).openStream())));
                String[] path = href.getValue().split("/");
                countryName = path[path.length - 1];
                break;
              }
            }
          }

          if (countryName == null) {
            log.warn("No article available about " + countryLanguage.getHomeCountryNative() + " in " + language.getEnglishName());
            continue;
          }

        }

        countryName = URLDecoder.decode(countryName, "UTF8");
        File file = new File(language.getTrainingDataPath(), countryName + ".txt");
        Writer w = new OutputStreamWriter(new FileOutputStream(file), "UTF8");
        write(getNode(parser.getDocument(), new int[]{1, 3, 1, 1, 1}), "", "0", w);
        w.close();

        System.currentTimeMillis();

      }
    }


    System.out.println("tokenizing");
    File csvArffFile = new File(root.getDataPath(), "ngram_csv.arff");
    Writer arffWriter = new OutputStreamWriter(new FileOutputStream(csvArffFile), "UTF8");
    writeCSVArff(arffWriter);
    arffWriter.close();
    Reader csvArffReader = new InputStreamReader(new FileInputStream(csvArffFile), "UTF8");
    Instances instances = new Instances(csvArffReader);
    csvArffReader.close();

    System.out.println("make an attribute out of each token");

    StringToWordVector stringToWordVector = new StringToWordVector(extractedNGramsPerLanguage * root.getLanguagesByISO().size());
    stringToWordVector.setInputFormat(instances);
    stringToWordVector.setDelimiters(";");
    stringToWordVector.setNormalizeDocLength(new SelectedTag(StringToWordVector.FILTER_NORMALIZE_ALL, StringToWordVector.TAGS_FILTER));
    stringToWordVector.setOutputWordCounts(true);

    instances = applyFilter(instances, stringToWordVector);

    System.out.println("move class to last attribute");

    Copy copy = new Copy();
    copy.setAttributeIndices("first");
    copy.setInputFormat(instances);
    instances = applyFilter(instances, copy);

    Remove remove = new Remove();
    remove.setAttributeIndices("first");
    remove.setInputFormat(instances);

    instances = applyFilter(instances, remove);
    instances.setClass(instances.attribute("Copy of class"));

    arffWriter = new OutputStreamWriter(new FileOutputStream(new File(root.getDataPath(), "ngrams.arff")), "UTF8");
    arffWriter.write(instances.toString());
    arffWriter.close();

    System.out.println("feature selection");

    AttributeSelection attributeSelection = new AttributeSelection();
    InfoGainAttributeEval infoGain = new InfoGainAttributeEval();
    attributeSelection.setEvaluator(infoGain);
    attributeSelection.setInputFormat(instances);
    Ranker ranker = new Ranker();
    ranker.setNumToSelect(featuredNGramsPerLanguage * root.getLanguagesByISO().size());
    attributeSelection.setSearch(ranker);

    instances = applyFilter(instances, attributeSelection);

    instances.setClass(instances.attribute("Copy of class"));

    Writer w = new OutputStreamWriter(new FileOutputStream(new File(root.getDataPath(), "trainingData.arff")), "UTF8");
    w.write(instances.toString());
    w.close();

    this.instances = instances;
  }

  public void writeCSVArff(Writer writer) throws IOException {
    writer.write("@RELATION langdetect\n@ATTRIBUTE csv_ngrams STRING\n@ATTRIBUTE class {");
    for (Iterator<Language> it = root.getLanguagesByISO().values().iterator(); it.hasNext();) {
      Language classLang = it.next();
      writer.write(classLang.getISO());
      if (it.hasNext()) {
        writer.write(", ");
      }
    }
    writer.write("}\n\n@DATA\n");

    for (Language relatedLanguage : root.getLanguagesByISO().values()) {

      for (File file : relatedLanguage.getTrainingDataPath().listFiles(new FilenameFilter() {
        private int accepted = 0;

        public boolean accept(File file, String string) {
          if (accepted >= trainingInstancesPerLanguage) {
            return false;
          }
          accepted++;
          return string.matches("^.+\\.txt$");

        }
      })) {
        String line;
        BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF8"));
        while ((line = br.readLine()) != null) {
          if (line.length() > 160) {
            writer.write("\n");
            writeCSVGrams(writer, line);
            writer.write(", ");
            writer.write(relatedLanguage.getISO());
          }
        }
        br.close();
      }
    }

    writer.close();
  }

  private void writeCSVGrams(Writer writer, String line) throws IOException {
    writer.write("\"");
    TokenStream ts = analyzer.tokenStream(null, new StringReader(line));
    Token token;
    while ((token = ts.next()) != null) {
      writer.write(token.termText());
      writer.write(";");
    }
    writer.write("\"");
  }

  // html dom helpers

  public static Node getNode(Node start, int[] path) {
    Node node = start;
    for (int child : path) {
      node = node.getChildNodes().item(child);
    }
    return node;
  }

  public static List<Node> searchRecursive(Node start, String regexp, Class _class) {
    LinkedList<Node> matches = new LinkedList<Node>();
    searchRecursive(start, Pattern.compile(regexp), _class, matches, "0");
    return matches;
  }

  public static List<Node> searchRecursive(Node start, Pattern regexp, Class _class, List<Node> matches, String path) {
    if (_class == null || start.getClass().equals(_class)) {
      if (regexp.matcher(start.getTextContent()).matches()) {
        //System.out.println(path + start.getTextContent());
        matches.add(start);
      }
    }
    for (int child = 0; child < start.getChildNodes().getLength(); child++) {
      searchRecursive(start.getChildNodes().item(child), regexp, _class, matches, path + "." + child);
    }
    return matches;
  }


  public static void write(Node node, String indent, String path, Writer writer) throws IOException {
    //System.out.println(indent + node.getClass().getName() + " " + path);
    if (node instanceof org.apache.xerces.dom.TextImpl) {
      //System.out.println(node.getTextContent());
      writer.write(node.getTextContent());
    }
    int i = 0;
    Node child = node.getFirstChild();
    while (child != null) {
      write(child, indent + " ", path + "." + i, writer);
      child = child.getNextSibling();
      i++;
    }
  }


}

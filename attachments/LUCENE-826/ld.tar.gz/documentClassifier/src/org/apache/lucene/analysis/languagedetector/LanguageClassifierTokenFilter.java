package org.apache.lucene.analysis.languagedetector;

import org.apache.lucene.analysis.Token;
import org.apache.lucene.analysis.TokenFilter;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.ngram.EdgeNGramTokenizer;
import org.apache.lucene.analysis.ngram.NGramTokenizer;

import java.io.IOException;
import java.io.StringReader;
import java.util.LinkedList;

/**
 * User: kalle
 * Date: 2007-mar-04
 * Time: 20:08:10
 */
public class LanguageClassifierTokenFilter extends TokenFilter {

  // private static Log log = LogFactory.getLog(LangGramTokenFilter.class);
  // private static long serialVersionUID = 1l;

  LinkedList<Token> buf = new LinkedList<Token>();


  public LanguageClassifierTokenFilter(TokenStream input) {
    super(input);
  }

  public Token next() throws IOException {
    while (buf.size() == 0) {
      Token token = input.next();
      if (token == null) {
        return null;
      }

      Token gramToken;

      // double characters
      NGramTokenizer ngramTokenizer = new NGramTokenizer(new StringReader(token.termText()), 2, 2);
      while ((gramToken = ngramTokenizer.next()) != null) {
        char[] c = token.termText().toCharArray();
        if (c[0] == c[1]) {
          buf.add(gramToken);
        }
      }

      // raw word
      buf.add(new Token("^"+token.termText()+"$", token.startOffset(), token.endOffset(), "complete word"));

      if (token.termText().length() > 3) {

        EdgeNGramTokenizer edgeGramTokenizer = new EdgeNGramTokenizer(new StringReader(token.termText()), EdgeNGramTokenizer.Side.FRONT, 2, 3);
        while ((gramToken = edgeGramTokenizer.next()) != null) {
          gramToken.setTermText("^" + gramToken.termText());
          buf.add(gramToken);
        }
        edgeGramTokenizer = new EdgeNGramTokenizer(new StringReader(token.termText()), EdgeNGramTokenizer.Side.BACK, 2, 3);
        while ((gramToken = edgeGramTokenizer.next()) != null) {
          gramToken.setTermText(gramToken.termText() + "$");
          buf.add(gramToken);
        }
      }
    }

    if (buf.size() > 0) {
      return buf.removeFirst();
    } else {
      return null;
    }
  }
}

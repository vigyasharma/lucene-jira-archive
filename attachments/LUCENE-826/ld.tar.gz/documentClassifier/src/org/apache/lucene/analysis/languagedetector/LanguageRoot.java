package org.apache.lucene.analysis.languagedetector;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * User: kalle
 * Date: 2007-mar-05
 * Time: 19:18:55
 */
public class LanguageRoot extends LanguageBranch {

  // private static Log log = LogFactory.getLog(LanguageRoot.class);
  // private static long serialVersionUID = 1l;

  /**
   * todo refactor, move to classifier
   */
  private File dataPath;

  private Map<String, Language> languagesByISO = new HashMap<String, Language>();
  private Map<String, LanguageBranch> branchesByName = new HashMap<String, LanguageBranch>();


  public LanguageRoot(File dataPath) {
    super(null, "root");
    branchesByName.put(null, this);
    this.dataPath = dataPath;
  }

  /**
   * todo refactor, move to classifier
   */
  public File getDataPath() {
    return dataPath;
  }

  public void load() throws IOException {
    languagesByISO = new HashMap<String, Language>();
    branchesByName = new HashMap<String, LanguageBranch>();

  }

  public void save() throws IOException {
    mkdirs();
  }

  public void mkdirs() {
    mkdirs(this);
  }

  private void mkdirs(LanguageBranch branch) {
    for (LanguageNode node : branch.getChildren()) {
      node.getDataPath().mkdirs();
      if (node instanceof LanguageBranch) {
        mkdirs((LanguageBranch) node);
      } else {
        node.getTestDataPath().mkdirs();
        node.getTrainingDataPath().mkdirs();        
      }
    }
  }

  public void addBranch(String name) {
    addBranch(name, this);
  }

  public void addLanguage(String ISO, String enlishName, String wikipediaDomainPrefix, String homeCountryNative) {
    addLanguage(this, ISO, enlishName, wikipediaDomainPrefix, homeCountryNative);
  }

  public void addBranch(String name, String parent) {
    LanguageBranch parentBranch = getBranchesByName().get(parent);
    if (parentBranch == null) {
      throw new NullPointerException("Parent '" + parent + "' not found");
    }
    addBranch(name, parentBranch);
  }

  public void addBranch(String name, LanguageBranch parent) {
    branchesByName.put(name, new LanguageBranch(parent, name));
  }

  public void addLanguage(String parent, String ISO, String englishName, String wikipediaDomainPrefix, String homeCountryNative) {
    LanguageBranch parentBranch = getBranchesByName().get(parent);
    if (parentBranch == null) {
      throw new NullPointerException("Parent '" + parent + "' not found");
    }
    addLanguage(parentBranch, ISO, englishName, wikipediaDomainPrefix, homeCountryNative);
  }

  public void addLanguage(LanguageBranch parent, String ISO, String englishName, String wikipediaDomainPrefix, String homeCountryNative) {
    languagesByISO.put(ISO, new Language(parent, ISO, englishName, wikipediaDomainPrefix, homeCountryNative));
  }


  public Map<String, Language> getLanguagesByISO() {
    return languagesByISO;
  }

  public Map<String, LanguageBranch> getBranchesByName() {
    return branchesByName;
  }


  public LanguageRoot getRoot() {
    return this;
  }


  protected Double distanceTo(LanguageNode target, Set<LanguageNode> visitedNodes, double currentDistance) {
    if (target.equals(this)) {
      return currentDistance;
    }
    visitedNodes.add(this);
    for (LanguageNode child : getChildren()) {
      if (!visitedNodes.contains(child)) {
        Double ret = child.distanceTo(target, visitedNodes, currentDistance + child.getDistanceToParent());
        if (ret != null) {
          return ret;
        }
      }
    }
    return null;
  }
}
